# Control Plus - Sistema de Inventario con MySQL

Sistema completo de control de inventario desarrollado en Python con Flet y base de datos MySQL.

## 🚀 Características

- ✅ Base de datos MySQL completa
- ✅ Gestión de usuarios con autenticación
- ✅ Control de inventario en tiempo real
- ✅ Sistema de compras y carrito
- ✅ Configuraciones persistentes
- ✅ Interfaz gráfica moderna
- ✅ Alertas de stock bajo
- ✅ Historial de compras

## 📋 Requisitos Previos

1. **Python 3.8+**
2. **MySQL Server 8.0+**
3. **Dependencias Python** (ver requirements.txt)

## 🛠️ Instalación

### 1. Instalar dependencias
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Configurar MySQL
- Asegúrate de que MySQL esté ejecutándose
- Usuario: `root`
- Contraseña: `1234`
- Puerto: `3306`

### 3. Inicializar base de datos
\`\`\`bash
python run_sql_scripts.py
\`\`\`

### 4. Ejecutar aplicación
\`\`\`bash
python app_with_database.py
\`\`\`

## 🗄️ Estructura de la Base de Datos

### Tablas principales:
- `users` - Usuarios del sistema
- `products` - Catálogo de productos
- `inventory_items` - Control de inventario
- `purchase_history` - Historial de compras
- `purchase_details` - Detalles de compras
- `system_config` - Configuraciones del sistema
- `inventory_movements` - Movimientos de stock

## 🔑 Credenciales de Prueba

- **Email:** admin@test.com
- **Contraseña:** 123456

## 📊 Funcionalidades

### Gestión de Usuarios
- Registro y autenticación
- Perfiles de usuario
- Cambio de contraseñas

### Control de Inventario
- Agregar/editar productos
- Monitoreo de stock
- Alertas de stock bajo
- Historial de movimientos

### Sistema de Compras
- Carrito de compras
- Procesamiento de pedidos
- Historial de compras
- Actualización automática de stock

### Configuraciones
- Base de datos
- Notificaciones
- Alertas de stock
- Respaldos automáticos
- Configuración de impresoras

## 🔧 Configuración de Base de Datos

Modifica los parámetros de conexión en `database_manager.py`:

```python
self.host = 'localhost'
self.port = 3306
self.user = 'root'
self.password = '1234'
self.database = 'coflita'
