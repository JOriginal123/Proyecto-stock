import mysql.connector
from mysql.connector import Error
import hashlib
from typing import Optional, List, Dict, Any
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.connection = None
        self.host = 'localhost'
        self.port = 3306
        self.user = 'root'
        self.password = '1234'
        self.database = 'coflita'
    
    def connect(self) -> bool:
        """Conectar a la base de datos MySQL"""
        try:
            self.connection = mysql.connector.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database,
                ssl_disabled=True,
                autocommit=True
            )
            
            if self.connection.is_connected():
                logger.info("✅ Conexión exitosa a la base de datos")
                return True
                
        except Error as e:
            logger.error(f"❌ Error de conexión: {e}")
            return False
        
        return False
    
    def disconnect(self):
        """Desconectar de la base de datos"""
        if self.connection and self.connection.is_connected():
            self.connection.close()
            logger.info("Conexión cerrada")
    
    def execute_query(self, query: str, params: tuple = None) -> Optional[List[Dict]]:
        """Ejecutar una consulta SELECT"""
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query, params or ())
            result = cursor.fetchall()
            cursor.close()
            return result
        except Error as e:
            logger.error(f"Error ejecutando consulta: {e}")
            return None
    
    def execute_update(self, query: str, params: tuple = None) -> bool:
        """Ejecutar una consulta INSERT, UPDATE o DELETE"""
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params or ())
            cursor.close()
            return True
        except Error as e:
            logger.error(f"Error ejecutando actualización: {e}")
            return False
    
    def get_last_insert_id(self) -> int:
        """Obtener el último ID insertado"""
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT LAST_INSERT_ID()")
            result = cursor.fetchone()
            cursor.close()
            return result[0] if result else 0
        except Error as e:
            logger.error(f"Error obteniendo último ID: {e}")
            return 0
    
    # Métodos para usuarios
    def authenticate_user(self, email: str, password: str) -> Optional[Dict]:
        """Autenticar usuario"""
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        query = "SELECT id, username, email FROM users WHERE email = %s AND password_hash = %s"
        result = self.execute_query(query, (email, password_hash))
        return result[0] if result else None
    
    def register_user(self, username: str, email: str, password: str) -> tuple[bool, str]:
        """Registrar nuevo usuario"""
        # Verificar si el email ya existe
        check_query = "SELECT id FROM users WHERE email = %s"
        existing = self.execute_query(check_query, (email,))
        
        if existing:
            return False, "El email ya está registrado"
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        insert_query = "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)"
        
        if self.execute_update(insert_query, (username, email, password_hash)):
            return True, "Usuario registrado exitosamente"
        else:
            return False, "Error al registrar usuario"
    
    def update_user(self, user_id: int, username: str, email: str) -> bool:
        """Actualizar información del usuario"""
        query = "UPDATE users SET username = %s, email = %s WHERE id = %s"
        return self.execute_update(query, (username, email, user_id))
    
    def change_password(self, user_id: int, current_password: str, new_password: str) -> bool:
        """Cambiar contraseña del usuario"""
        current_hash = hashlib.sha256(current_password.encode()).hexdigest()
        
        # Verificar contraseña actual
        check_query = "SELECT id FROM users WHERE id = %s AND password_hash = %s"
        result = self.execute_query(check_query, (user_id, current_hash))
        
        if not result:
            return False
        
        new_hash = hashlib.sha256(new_password.encode()).hexdigest()
        update_query = "UPDATE users SET password_hash = %s WHERE id = %s"
        return self.execute_update(update_query, (new_hash, user_id))
    
    # Métodos para productos
    def get_all_products(self) -> List[Dict]:
        """Obtener todos los productos"""
        query = "SELECT * FROM products ORDER BY name"
        return self.execute_query(query) or []
    
    def get_product_by_id(self, product_id: int) -> Optional[Dict]:
        """Obtener producto por ID"""
        query = "SELECT * FROM products WHERE id = %s"
        result = self.execute_query(query, (product_id,))
        return result[0] if result else None
    
    def add_product(self, product_data: Dict) -> bool:
        """Agregar nuevo producto"""
        query = """
        INSERT INTO products (name, price, stock, category, description, image) 
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        params = (
            product_data['name'],
            product_data['price'],
            product_data['stock'],
            product_data['category'],
            product_data['description'],
            product_data['image']
        )
        
        if self.execute_update(query, params):
            product_id = self.get_last_insert_id()
            # Agregar al inventario
            inv_query = """
            INSERT INTO inventory_items (product_id, name, current_stock, min_stock, max_stock)
            VALUES (%s, %s, %s, %s, %s)
            """
            inv_params = (
                product_id,
                product_data['name'],
                product_data['stock'],
                product_data.get('min_stock', 5),
                product_data.get('max_stock', 50)
            )
            return self.execute_update(inv_query, inv_params)
        
        return False
    
    def update_product_stock(self, product_id: int, new_stock: int) -> bool:
        """Actualizar stock del producto"""
        # Actualizar en productos
        query1 = "UPDATE products SET stock = %s WHERE id = %s"
        # Actualizar en inventario
        query2 = "UPDATE inventory_items SET current_stock = %s WHERE product_id = %s"
        
        return (self.execute_update(query1, (new_stock, product_id)) and 
                self.execute_update(query2, (new_stock, product_id)))
    
    # Métodos para inventario
    def get_inventory_items(self) -> List[Dict]:
        """Obtener items del inventario"""
        query = """
        SELECT i.*, p.name as product_name 
        FROM inventory_items i 
        LEFT JOIN products p ON i.product_id = p.id 
        ORDER BY i.name
        """
        return self.execute_query(query) or []
    
    def get_low_stock_items(self, threshold: int = 5) -> List[Dict]:
        """Obtener productos con stock bajo"""
        query = "SELECT * FROM inventory_items WHERE current_stock <= %s"
        return self.execute_query(query, (threshold,)) or []
    
    # Métodos para historial de compras
    def add_purchase(self, user_id: int, total: float, items: List[Dict]) -> bool:
        """Agregar nueva compra"""
        try:
            # Insertar compra principal
            purchase_query = """
            INSERT INTO purchase_history (user_id, total, items_count, purchase_date) 
            VALUES (%s, %s, %s, CURDATE())
            """
            
            if not self.execute_update(purchase_query, (user_id, total, len(items))):
                return False
            
            purchase_id = self.get_last_insert_id()
            
            # Insertar detalles de compra
            for item in items:
                detail_query = """
                INSERT INTO purchase_details (purchase_id, product_id, product_name, quantity, unit_price, subtotal)
                VALUES (%s, %s, %s, %s, %s, %s)
                """
                detail_params = (
                    purchase_id,
                    item['product']['id'],
                    item['product']['name'],
                    item['quantity'],
                    item['product']['price'],
                    item['subtotal']
                )
                
                if not self.execute_update(detail_query, detail_params):
                    return False
                
                # Actualizar stock
                new_stock = item['product']['stock'] - item['quantity']
                if not self.update_product_stock(item['product']['id'], max(0, new_stock)):
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error procesando compra: {e}")
            return False
    
    def get_user_purchases(self, user_id: int) -> List[Dict]:
        """Obtener historial de compras del usuario"""
        query = """
        SELECT * FROM purchase_history 
        WHERE user_id = %s 
        ORDER BY purchase_date DESC
        """
        return self.execute_query(query, (user_id,)) or []
    
    # Métodos para configuración del sistema
    def get_system_config(self) -> Dict[str, str]:
        """Obtener configuración del sistema"""
        query = "SELECT config_key, config_value FROM system_config"
        result = self.execute_query(query) or []
        return {item['config_key']: item['config_value'] for item in result}
    
    def update_system_config(self, config_key: str, config_value: str) -> bool:
        """Actualizar configuración del sistema"""
        query = """
        INSERT INTO system_config (config_key, config_value) 
        VALUES (%s, %s) 
        ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)
        """
        return self.execute_update(query, (config_key, config_value))
    
    def test_connection(self) -> tuple[bool, str]:
        """Probar conexión a la base de datos"""
        try:
            if self.connect():
                # Probar una consulta simple
                result = self.execute_query("SELECT 1 as test")
                if result:
                    return True, "Conexión exitosa y base de datos operativa"
                else:
                    return False, "Conexión establecida pero error en consulta"
            else:
                return False, "No se pudo establecer conexión"
        except Exception as e:
            return False, f"Error de conexión: {str(e)}"

# Instancia global del gestor de base de datos
db_manager = DatabaseManager()
