"""
Script para ejecutar los archivos SQL de inicialización
"""
import mysql.connector
from mysql.connector import Error
import os

def execute_sql_file(connection, file_path):
    """Ejecutar un archivo SQL"""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            sql_script = file.read()
        
        # Dividir el script en comandos individuales
        commands = sql_script.split(';')
        
        cursor = connection.cursor()
        
        for command in commands:
            command = command.strip()
            if command:
                try:
                    cursor.execute(command)
                    print(f"✅ Ejecutado: {command[:50]}...")
                except Error as e:
                    print(f"⚠️  Error en comando: {e}")
        
        cursor.close()
        connection.commit()
        print(f"✅ Archivo ejecutado exitosamente: {file_path}")
        
    except FileNotFoundError:
        print(f"❌ Archivo no encontrado: {file_path}")
    except Error as e:
        print(f"❌ Error ejecutando archivo {file_path}: {e}")

def main():
    """Función principal para ejecutar los scripts SQL"""
    try:
        # Conectar a MySQL (sin especificar base de datos para crearla)
        connection = mysql.connector.connect(
            host='localhost',
            port=3306,
            user='root',
            password='1234',
            ssl_disabled=True
        )
        
        if connection.is_connected():
            print("✅ Conectado a MySQL")
            
            # Ejecutar scripts en orden
            scripts = [
                'scripts/01_create_database.sql',
                'scripts/02_insert_initial_data.sql'
            ]
            
            for script in scripts:
                if os.path.exists(script):
                    execute_sql_file(connection, script)
                else:
                    print(f"❌ Script no encontrado: {script}")
            
            print("\n🎉 ¡Inicialización de base de datos completada!")
            print("📊 Base de datos 'coflita' creada y poblada")
            print("🔑 Usuario admin creado: admin@test.com / 123456")
            print("📦 Productos de ejemplo agregados")
            print("⚙️  Configuraciones del sistema establecidas")
            
    except Error as e:
        print(f"❌ Error de conexión: {e}")
        print("\n💡 Soluciones posibles:")
        print("1. Verificar que MySQL esté ejecutándose")
        print("2. Comprobar credenciales (usuario: root, contraseña: 1234)")
        print("3. Verificar que el puerto 3306 esté disponible")
        
    finally:
        if connection and connection.is_connected():
            connection.close()
            print("🔌 Conexión cerrada")

if __name__ == "__main__":
    main()
