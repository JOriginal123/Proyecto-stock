import flet as ft
import hashlib
import time
from database_manager import db_manager
from typing import List, Dict, Any

def main(page: ft.Page):
    page.title = "Control Plus - Sistema de Inventario"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 1200
    page.window_height = 800
    page.bgcolor = ft.colors.BLUE_GREY_50
    page.padding = 0

    # Variables globales del sistema
    current_screen = "welcome"
    user_logged_in = False
    user_data = {"id": None, "username": "", "email": ""}
    cart_items = []
    cart_total = 0.0
    
    # Configuraciones del sistema (se cargarán desde la BD)
    system_config = {}
    
    # Datos que se cargarán desde la base de datos
    products_db = []
    inventory_items = []
    filtered_products = []
    selected_product = None

    # Inicializar conexión a la base de datos
    def initialize_database():
        """Inicializar conexión y cargar datos"""
        if db_manager.connect():
            load_system_config()
            load_products()
            load_inventory()
            show_message("✅ Base de datos conectada exitosamente", ft.colors.GREEN)
            return True
        else:
            show_message("❌ Error conectando a la base de datos", ft.colors.RED)
            return False

    def load_system_config():
        """Cargar configuración del sistema desde la BD"""
        nonlocal system_config
        system_config = db_manager.get_system_config()
        
        # Valores por defecto si no existen en la BD
        defaults = {
            "database_host": "localhost",
            "database_port": "3306",
            "notifications_enabled": "true",
            "stock_alert_threshold": "5",
            "backup_frequency": "daily",
            "default_printer": "HP LaserJet",
            "language": "Español"
        }
        
        for key, value in defaults.items():
            if key not in system_config:
                system_config[key] = value

    def load_products():
        """Cargar productos desde la BD"""
        nonlocal products_db, filtered_products
        products_db = db_manager.get_all_products()
        filtered_products = products_db.copy()

    def load_inventory():
        """Cargar inventario desde la BD"""
        nonlocal inventory_items
        inventory_items = db_manager.get_inventory_items()

    # Función para mostrar mensajes
    def show_message(message, color=ft.colors.BLUE):
        try:
            snack_bar = ft.SnackBar(
                content=ft.Text(message),
                bgcolor=color,
            )
            page.overlay.append(snack_bar)
            snack_bar.open = True
            page.update()
        except:
            print(f"Mensaje: {message}")

    # Función para registrar usuario
    def register_user(username, email, password):
        return db_manager.register_user(username, email, password)

    # Función para autenticar usuario
    def authenticate_user(email, password):
        return db_manager.authenticate_user(email, password)

    def navigate_to(screen_name):
        nonlocal current_screen
        current_screen = screen_name
        update_screen()

    def update_screen():
        page.clean()
        
        if current_screen == "welcome":
            page.add(welcome_screen())
        elif current_screen == "login":
            page.add(login_screen())
        elif current_screen == "register":
            page.add(register_screen())
        elif current_screen == "main":
            page.add(main_screen())
        elif current_screen == "products":
            page.add(products_screen())
        elif current_screen == "inventory":
            page.add(inventory_screen())
        elif current_screen == "account":
            page.add(account_screen())
        elif current_screen == "config":
            page.add(config_screen())
        elif current_screen == "product_detail":
            page.add(product_detail_screen())
        elif current_screen == "cart":
            page.add(cart_screen())
        elif current_screen == "add_product":
            page.add(add_product_screen())
        elif current_screen == "database_test":
            page.add(database_test_screen())
        
        page.update()

    def update_cart_total():
        nonlocal cart_total
        cart_total = sum(item["subtotal"] for item in cart_items)

    # Función para agregar producto al inventario
    def add_product_to_inventory(product_data):
        success = db_manager.add_product(product_data)
        if success:
            load_products()
            load_inventory()
        return success

    # Pantalla de Bienvenida
    def welcome_screen():
        return ft.Container(
            content=ft.Column([
                ft.Container(height=100),
                ft.Text(
                    "Control Plus",
                    size=60,
                    weight=ft.FontWeight.BOLD,
                    color=ft.colors.WHITE,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    "Sistema de Control de Inventario",
                    size=24,
                    color=ft.colors.WHITE70,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    "Con Base de Datos MySQL",
                    size=16,
                    color=ft.colors.WHITE60,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=60),
                ft.Row([
                    ft.ElevatedButton(
                        "ENTRAR",
                        bgcolor=ft.colors.BLUE,
                        color=ft.colors.WHITE,
                        width=200,
                        height=60,
                        style=ft.ButtonStyle(
                            text_style=ft.TextStyle(size=20, weight=ft.FontWeight.BOLD),
                        ),
                        on_click=lambda _: navigate_to("login"),
                    ),
                    ft.ElevatedButton(
                        "PROBAR BD",
                        bgcolor=ft.colors.GREEN,
                        color=ft.colors.WHITE,
                        width=200,
                        height=60,
                        style=ft.ButtonStyle(
                            text_style=ft.TextStyle(size=20, weight=ft.FontWeight.BOLD),
                        ),
                        on_click=lambda _: navigate_to("database_test"),
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=20),
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            bgcolor=ft.colors.BLACK87,
            expand=True,
        )

    # Pantalla de prueba de base de datos
    def database_test_screen():
        connection_status = ft.Text("Probando conexión...", size=16)
        test_results = ft.Column(spacing=10)
        
        def test_database():
            connection_status.value = "Probando conexión..."
            connection_status.color = ft.colors.BLUE
            test_results.controls.clear()
            page.update()
            
            # Probar conexión
            success, message = db_manager.test_connection()
            
            if success:
                connection_status.value = "✅ " + message
                connection_status.color = ft.colors.GREEN
                
                # Mostrar estadísticas
                try:
                    products_count = len(db_manager.get_all_products())
                    inventory_count = len(db_manager.get_inventory_items())
                    low_stock_count = len(db_manager.get_low_stock_items())
                    
                    test_results.controls.extend([
                        ft.Card(
                            content=ft.Container(
                                content=ft.Column([
                                    ft.Text("Estadísticas de la Base de Datos", size=18, weight=ft.FontWeight.BOLD),
                                    ft.Divider(),
                                    ft.Text(f"Productos registrados: {products_count}"),
                                    ft.Text(f"Items en inventario: {inventory_count}"),
                                    ft.Text(f"Productos con stock bajo: {low_stock_count}"),
                                    ft.Text(f"Configuraciones: {len(system_config)}"),
                                ]),
                                padding=20,
                            )
                        ),
                        ft.Card(
                            content=ft.Container(
                                content=ft.Column([
                                    ft.Text("Configuración Actual", size=18, weight=ft.FontWeight.BOLD),
                                    ft.Divider(),
                                    ft.Text(f"Host: {db_manager.host}"),
                                    ft.Text(f"Puerto: {db_manager.port}"),
                                    ft.Text(f"Base de datos: {db_manager.database}"),
                                    ft.Text(f"Usuario: {db_manager.user}"),
                                ]),
                                padding=20,
                            )
                        )
                    ])
                    
                except Exception as e:
                    test_results.controls.append(
                        ft.Text(f"Error obteniendo estadísticas: {str(e)}", color=ft.colors.ORANGE)
                    )
            else:
                connection_status.value = "❌ " + message
                connection_status.color = ft.colors.RED
                
                test_results.controls.append(
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Soluciones posibles:", size=16, weight=ft.FontWeight.BOLD),
                                ft.Text("1. Verificar que MySQL esté ejecutándose"),
                                ft.Text("2. Comprobar credenciales de conexión"),
                                ft.Text("3. Ejecutar los scripts SQL de creación"),
                                ft.Text("4. Verificar permisos de usuario"),
                            ]),
                            padding=20,
                        )
                    )
                )
            
            page.update()
        
        # Ejecutar prueba automáticamente
        test_database()
        
        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.IconButton(
                            ft.icons.ARROW_BACK,
                            tooltip="Volver",
                            on_click=lambda _: navigate_to("welcome"),
                        ),
                        ft.Text(
                            "Prueba de Base de Datos",
                            size=24,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ]),
                    bgcolor=ft.colors.WHITE,
                    padding=20,
                    border=ft.border.only(bottom=ft.BorderSide(2, ft.colors.BLUE_GREY_200)),
                ),
                
                ft.Container(
                    content=ft.Column([
                        ft.Container(height=30),
                        ft.Icon(ft.icons.STORAGE, size=60, color=ft.colors.BLUE),
                        ft.Text("Estado de la Base de Datos", size=20, weight=ft.FontWeight.BOLD),
                        ft.Container(height=20),
                        connection_status,
                        ft.Container(height=20),
                        test_results,
                        ft.Container(height=30),
                        ft.Row([
                            ft.ElevatedButton(
                                "Probar Nuevamente",
                                bgcolor=ft.colors.BLUE,
                                color=ft.colors.WHITE,
                                width=180,
                                height=50,
                                on_click=lambda _: test_database(),
                            ),
                            ft.ElevatedButton(
                                "Inicializar Sistema",
                                bgcolor=ft.colors.GREEN,
                                color=ft.colors.WHITE,
                                width=180,
                                height=50,
                                on_click=lambda _: initialize_and_continue(),
                            ),
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=20),
                    ], alignment=ft.MainAxisAlignment.START, horizontal_alignment=ft.CrossAxisAlignment.CENTER, scroll=ft.ScrollMode.AUTO),
                    expand=True,
                    padding=40,
                ),
            ]),
            expand=True,
        )
    
    def initialize_and_continue():
        if initialize_database():
            show_message("Sistema inicializado correctamente", ft.colors.GREEN)
            time.sleep(1)
            navigate_to("login")
        else:
            show_message("Error inicializando el sistema", ft.colors.RED)

    # Pantalla de Login (modificada para usar BD)
    def login_screen():
        email_field = ft.TextField(
            label="Correo Electrónico",
            width=350,
            bgcolor=ft.colors.WHITE,
            border_radius=10,
            value="admin@test.com",
        )
        password_field = ft.TextField(
            label="Contraseña",
            password=True,
            width=350,
            bgcolor=ft.colors.WHITE,
            border_radius=10,
            value="123456",
        )
        
        status_text = ft.Text("", color=ft.colors.RED, size=14)
        
        def login_user(e):
            status_text.value = ""
            
            if not email_field.value or not email_field.value.strip():
                status_text.value = "Por favor ingrese su email"
                status_text.color = ft.colors.RED
                page.update()
                return
            
            if not password_field.value or not password_field.value.strip():
                status_text.value = "Por favor ingrese su contraseña"
                status_text.color = ft.colors.RED
                page.update()
                return
            
            status_text.value = "Iniciando sesión..."
            status_text.color = ft.colors.BLUE
            page.update()
            
            # Inicializar BD si no está conectada
            if not db_manager.connection or not db_manager.connection.is_connected():
                if not initialize_database():
                    status_text.value = "Error de conexión a la base de datos"
                    status_text.color = ft.colors.RED
                    page.update()
                    return
            
            user = authenticate_user(email_field.value.strip(), password_field.value)
            if user:
                nonlocal user_logged_in, user_data
                user_logged_in = True
                user_data = user
                status_text.value = "¡Login exitoso!"
                status_text.color = ft.colors.GREEN
                page.update()
                show_message("¡Bienvenido al sistema!", ft.colors.GREEN)
                time.sleep(0.5)
                navigate_to("main")
            else:
                status_text.value = "Email o contraseña incorrectos"
                status_text.color = ft.colors.RED
                show_message("Credenciales incorrectas", ft.colors.RED)
                page.update()
        
        return ft.Container(
            content=ft.Column([
                ft.Container(height=50),
                ft.Text(
                    "Inicio de Sesión",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    "Sistema con Base de Datos MySQL",
                    size=14,
                    color=ft.colors.BLUE_GREY,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=40),
                email_field,
                password_field,
                status_text,
                ft.Container(height=30),
                ft.ElevatedButton(
                    "INICIAR SESIÓN",
                    bgcolor=ft.colors.BLUE,
                    color=ft.colors.WHITE,
                    width=200,
                    height=50,
                    on_click=login_user,
                ),
                ft.Container(height=20),
                ft.TextButton(
                    "¿No tienes cuenta? Crea una aquí",
                    on_click=lambda _: navigate_to("register"),
                ),
                ft.TextButton(
                    "← Volver",
                    on_click=lambda _: navigate_to("welcome"),
                ),
                ft.Container(height=20),
                ft.Text(
                    "Usuario de prueba: admin@test.com / Contraseña: 123456",
                    size=12,
                    color=ft.colors.BLUE_GREY,
                    text_align=ft.TextAlign.CENTER,
                ),
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            bgcolor=ft.colors.BLUE_100,
            expand=True,
            padding=40,
        )

    # Resto de pantallas (simplificadas para el ejemplo)
    def main_screen():
        return ft.Container(
            content=ft.Column([
                ft.Container(height=50),
                ft.Text(
                    f"¡Bienvenido, {user_data.get('username', 'Usuario')}!",
                    size=32,
                    weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    "Sistema conectado a MySQL",
                    size=16,
                    color=ft.colors.GREEN,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=40),
                ft.Row([
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Productos", weight=ft.FontWeight.BOLD),
                                ft.Text(str(len(products_db)), size=32, color=ft.colors.BLUE),
                            ], alignment=ft.MainAxisAlignment.CENTER),
                            padding=20,
                            width=150,
                        ),
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Inventario", weight=ft.FontWeight.BOLD),
                                ft.Text(str(len(inventory_items)), size=32, color=ft.colors.GREEN),
                            ], alignment=ft.MainAxisAlignment.CENTER),
                            padding=20,
                            width=150,
                        ),
                    ),
                    ft.Card(
                        content=ft.Container(
                            content=ft.Column([
                                ft.Text("Stock Bajo", weight=ft.FontWeight.BOLD),
                                ft.Text(str(len([i for i in inventory_items if i.get('current_stock', 0) <= int(system_config.get('stock_alert_threshold', 5))])), 
                                       size=32, color=ft.colors.RED),
                            ], alignment=ft.MainAxisAlignment.CENTER),
                            padding=20,
                            width=150,
                        ),
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=20),
                ft.Container(height=40),
                ft.Row([
                    ft.ElevatedButton(
                        "Ver Productos",
                        bgcolor=ft.colors.BLUE,
                        color=ft.colors.WHITE,
                        width=150,
                        height=50,
                        on_click=lambda _: navigate_to("products"),
                    ),
                    ft.ElevatedButton(
                        "Gestionar Inventario",
                        bgcolor=ft.colors.GREEN,
                        color=ft.colors.WHITE,
                        width=180,
                        height=50,
                        on_click=lambda _: navigate_to("inventory"),
                    ),
                    ft.ElevatedButton(
                        "Mi Cuenta",
                        bgcolor=ft.colors.PURPLE,
                        color=ft.colors.WHITE,
                        width=150,
                        height=50,
                        on_click=lambda _: navigate_to("account"),
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=20),
                ft.Container(height=40),
                ft.ElevatedButton(
                    "Cerrar Sesión",
                    bgcolor=ft.colors.RED,
                    color=ft.colors.WHITE,
                    width=150,
                    height=50,
                    on_click=lambda _: navigate_to("welcome"),
                ),
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            expand=True,
        )

    # Pantallas básicas para completar la funcionalidad
    def products_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Productos desde Base de Datos", size=24, weight=ft.FontWeight.BOLD),
                ft.Text(f"Total de productos: {len(products_db)}", size=16),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("main")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def inventory_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Inventario desde Base de Datos", size=24, weight=ft.FontWeight.BOLD),
                ft.Text(f"Items en inventario: {len(inventory_items)}", size=16),
                ft.ElevatedButton("Agregar Producto", on_click=lambda _: navigate_to("add_product")),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("main")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def add_product_screen():
        name_field = ft.TextField(label="Nombre del Producto", width=300)
        price_field = ft.TextField(label="Precio", width=300)
        stock_field = ft.TextField(label="Stock", width=300, value="10")
        
        def save_product():
            if name_field.value and price_field.value:
                product_data = {
                    'name': name_field.value,
                    'price': float(price_field.value),
                    'stock': int(stock_field.value),
                    'category': 'General',
                    'description': '',
                    'image': '📦'
                }
                
                if add_product_to_inventory(product_data):
                    show_message("Producto agregado exitosamente", ft.colors.GREEN)
                    navigate_to("inventory")
                else:
                    show_message("Error agregando producto", ft.colors.RED)
        
        return ft.Container(
            content=ft.Column([
                ft.Text("Agregar Producto", size=24, weight=ft.FontWeight.BOLD),
                name_field,
                price_field,
                stock_field,
                ft.Row([
                    ft.ElevatedButton("Cancelar", on_click=lambda _: navigate_to("inventory")),
                    ft.ElevatedButton("Guardar", on_click=lambda _: save_product()),
                ], alignment=ft.MainAxisAlignment.CENTER, spacing=20),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def account_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Mi Cuenta", size=24, weight=ft.FontWeight.BOLD),
                ft.Text(f"Usuario: {user_data.get('username', 'N/A')}", size=16),
                ft.Text(f"Email: {user_data.get('email', 'N/A')}", size=16),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("main")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def config_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Configuración", size=24, weight=ft.FontWeight.BOLD),
                ft.Text("Configuraciones cargadas desde BD", size=16),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("main")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def register_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Registro de Usuario", size=24, weight=ft.FontWeight.BOLD),
                ft.Text("Funcionalidad de registro disponible", size=16),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("login")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def product_detail_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Detalle del Producto", size=24, weight=ft.FontWeight.BOLD),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("products")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    def cart_screen():
        return ft.Container(
            content=ft.Column([
                ft.Text("Carrito de Compras", size=24, weight=ft.FontWeight.BOLD),
                ft.ElevatedButton("Volver", on_click=lambda _: navigate_to("main")),
            ], alignment=ft.MainAxisAlignment.CENTER),
            expand=True,
        )

    # Inicializar la aplicación
    print("🚀 Iniciando Control Plus con Base de Datos MySQL...")
    print("📊 Base de datos: coflita")
    print("🔑 Usuario de prueba: admin@test.com / 123456")
    print("✅ Sistema completo con persistencia de datos")
    
    update_screen()

if __name__ == "__main__":
    ft.app(target=main, view=ft.WEB_BROWSER)
