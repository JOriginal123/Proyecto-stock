USE coflita;

-- Insertar usuario administrador por defecto
INSERT INTO users (username, email, password_hash) VALUES 
('Administrador', 'admin@test.com', SHA2('123456', 256))
ON DUPLICATE KEY UPDATE username = VALUES(username);

-- Insertar productos iniciales
INSERT INTO products (name, price, stock, category, description, image) VALUES 
('Laptop Dell', 850.99, 15, 'Electrónicos', 'Laptop Dell Inspiron 15, 8GB RAM, 256GB SSD', '💻'),
('Mouse Inalámbrico', 25.50, 45, 'Accesorios', 'Mouse inalámbrico ergonómico con 3 botones', '🖱️'),
('Teclado Mecánico', 75.00, 20, 'Accesorios', 'Teclado mecánico RGB con switches azules', '⌨️'),
('Monitor 24"', 199.99, 8, 'Electrónicos', 'Monitor LED 24 pulgadas Full HD', '🖥️'),
('Webcam HD', 45.75, 30, 'Accesorios', 'Webcam HD 1080p con micrófono integrado', '📹'),
('Auriculares', 35.00, 25, 'Audio', 'Auriculares con cancelación de ruido', '🎧'),
('Tablet Samsung', 299.99, 12, 'Electrónicos', 'Tablet Samsung Galaxy 10.1 pulgadas', '📱'),
('Cargador USB-C', 15.99, 50, 'Accesorios', 'Cargador rápido USB-C 65W', '🔌')
ON DUPLICATE KEY UPDATE 
    price = VALUES(price),
    stock = VALUES(stock),
    category = VALUES(category),
    description = VALUES(description),
    image = VALUES(image);

-- Insertar items de inventario basados en productos
INSERT INTO inventory_items (product_id, name, current_stock, min_stock, max_stock)
SELECT id, name, stock, 5, 50 FROM products
ON DUPLICATE KEY UPDATE 
    current_stock = VALUES(current_stock),
    min_stock = VALUES(min_stock),
    max_stock = VALUES(max_stock);

-- Insertar configuraciones del sistema
INSERT INTO system_config (config_key, config_value, description) VALUES 
('database_host', 'localhost', 'Host de la base de datos'),
('database_port', '3306', 'Puerto de la base de datos'),
('notifications_enabled', 'true', 'Habilitar notificaciones del sistema'),
('stock_alert_threshold', '5', 'Umbral de alerta de stock bajo'),
('backup_frequency', 'daily', 'Frecuencia de respaldo automático'),
('default_printer', 'HP LaserJet', 'Impresora predeterminada del sistema'),
('language', 'Español', 'Idioma del sistema')
ON DUPLICATE KEY UPDATE 
    config_value = VALUES(config_value),
    description = VALUES(description);

-- Insertar historial de compras de ejemplo
INSERT INTO purchase_history (user_id, total, items_count, status, purchase_date) VALUES 
(1, 875.99, 2, 'Completado', '2024-06-01'),
(1, 125.50, 3, 'Completado', '2024-05-28'),
(1, 299.99, 1, 'Completado', '2024-05-25'),
(1, 45.75, 1, 'Completado', '2024-05-20')
ON DUPLICATE KEY UPDATE 
    total = VALUES(total),
    items_count = VALUES(items_count),
    status = VALUES(status);
